import React from "react";
import humidity from "../../assets/humidity.png"
import pressure from "../../assets/pressure.png"
import sun from "../../assets/sun.png"
import "./weatherCard.css"
import moment from "moment";

const WeatherCard = (props) => {
  const data = props.response;
  
  return (
    <div>
    {data===undefined || data === ""? "" : 
    <div>
        {data && data.message ? <div className="weather-message"> {data.message} </div> : 
        <>
        <div className="weather-card-container">
          <h1> {data.name} </h1>
          <p> {moment(data.dt * 1000).format('LL')} </p>
          <div className="weather-card-temp">
            <img
              src={`http://openweathermap.org/img/w/${data.weather[0].icon}.png`}
              alt="not found"
            />
            <h2>{data.main.temp} {props.unit}</h2>
          </div>
          <p className="weather-card-desc">{data.weather[0].description}</p>
          <div className="weather-card-data"> 
            <div className="weather-card-data-header">
                <img src={humidity} alt="humidity" /> 
                <p>Humidity</p>
            </div>
            <div>{data.main.humidity} % </div>
          </div>
          <div className="weather-card-data">
            <div className="weather-card-data-header">
                <img src={pressure} alt="pressure" /> 
                <p>pressure</p>
            </div>
            <div>{data.main.pressure} hPa </div>
          </div>
          <div className="weather-card-data">
            <div className="weather-card-data-header">
                <img src={sun} alt="temp" /> 
                <p>Min Temp</p>
            </div>
            <div>{data.main.temp_min}  {props.unit}</div> 
          </div>
          <div className="weather-card-data">
            <div className="weather-card-data-header">
                <img src={sun} alt="temp" />
                <p>Max Temp</p>
            </div>
            <div> {data.main.temp_max} {props.unit}</div> 
          </div>
          </div>
        </>}
    </div>
    }
    </div>
  );
};

export default WeatherCard;
