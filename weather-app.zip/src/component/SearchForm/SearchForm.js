import React, { useState } from 'react';
import WeatherCard from '../WeatherCard/WeatherCard';
import WeatherForecastCard from '../WeatherForecast/weatherForecast';
import "./searchForm.css";

const SearchForm = () => {
    const [city,setCity] = useState("")
    const [weatherData,setWeatherData] = useState();
    const [weatherForecast,setWeatherForecast] = useState();
    const [unit,setUnit] = useState('metric');

    const handleSubmit = async () => {
       let url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=${unit}&appid=1018683ec214e74d723b14a8e3443011`
        let response = await fetch(url)
        let jsonData = await response.json()
        setWeatherData(jsonData);
        if(jsonData.message){
            setWeatherForecast('')
        }
        if(jsonData && !jsonData.message){
            let url2 = `https://api.openweathermap.org/data/2.5/forecast?lat=${jsonData.coord.lat}&lon=${jsonData.coord.lon}&cnt=8&units=metric&appid=1018683ec214e74d723b14a8e3443011`
            let forecastData = await fetch(url2)
            let forecastJsonData = await forecastData.json();
            setWeatherForecast(forecastJsonData);
            setCity('');
        }
    }
    
    return (
        <>
        <div>
            <input className='city' placeholder='Enter City' type='text' value={city} onChange={(e)=>setCity(e.target.value)}/>
            <label htmlFor="metric">Celsius</label>
            <input type='radio' id='metric' name='units' defaultChecked={'metric'} value={'metric'}  onClick={(e)=>setUnit(e.target.value)} />
            <label htmlFor="imperial">Kelvin</label>
            <input type='radio' id='imperial' name='units' value={'imperial'} onClick={(e)=>setUnit(e.target.value)} />
            <button className='submit' type='submit' onClick={handleSubmit}>Search</button>
        </div>
        
        <WeatherCard response={weatherData} weatherForecast={weatherForecast} unit={unit==="metric"?"°C":"K"} />
        <WeatherForecastCard weatherForecast={weatherForecast} />
        </>
    )
}

export default SearchForm;