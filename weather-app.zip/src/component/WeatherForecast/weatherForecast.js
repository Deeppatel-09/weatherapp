import React from "react";
import "./weatherForecast.css";
import moment from "moment";

const WeatherForecastCard = ({weatherForecast}) => {
    return (
        <>
        <div className="weather-forecast-card">
        {weatherForecast && weatherForecast.list.map((e,idx)=> ( 
            <div className="weather-forecast-container" key={idx}>
                <p> {moment(e.dt_txt).format("MMM Do YY")} </p>
                <div>{moment(e.dt_txt).format("LT")}</div>
                <div className="weather-card-temp">
                    <img
                        src={`http://openweathermap.org/img/w/${e.weather[0].icon}.png`}
                        alt="not found"
                    />
                    <p>{e.main.temp.toFixed()} °C</p> 
                    <p>{e.main.humidity}%</p>
                </div>
            </div>
        ))}
        </div>
        </>
    )
}

export default WeatherForecastCard;