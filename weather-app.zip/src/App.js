import './App.css';
import SearchForm from './component/SearchForm/SearchForm';

function App() {
  return (
    <div className="App">
      <SearchForm />
    </div>
  );
}

export default App;